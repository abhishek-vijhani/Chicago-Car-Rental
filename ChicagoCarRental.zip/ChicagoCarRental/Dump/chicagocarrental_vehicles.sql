-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: chicagocarrental
-- ------------------------------------------------------
-- Server version	5.7.19-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `vehicles`
--

DROP TABLE IF EXISTS `vehicles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vehicles` (
  `vehicleid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `registrationnumber` varchar(45) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `mileage` varchar(45) DEFAULT NULL,
  `passengercapacity` varchar(45) DEFAULT NULL,
  `transmission` varchar(45) DEFAULT NULL,
  `image` varchar(45) DEFAULT NULL,
  `locationid` int(11) DEFAULT NULL,
  PRIMARY KEY (`vehicleid`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicles`
--

LOCK TABLES `vehicles` WRITE;
/*!40000 ALTER TABLE `vehicles` DISABLE KEYS */;
INSERT INTO `vehicles` VALUES (1,'Audi A3','test123456','standard',100,'10','2','auto','AudiA3.jpg',4),(2,'BMW 650i Convertible','test1234567','luxury',100,'10','2','auto','BMW 650i Convertible.jpg',4),(3,'Cadillac Escalade','test1234567','suv',108,'10','4','auto','Cadillac Escalade.jpg',4),(4,'Chevrolet Camaro Convertible','test12345678','luxury',80,'20','2','auto','Chevrolet Camaro Convertible.jpg',4),(5,'Chevrolet Camaro SS Convertible','test123456','luxury',90,'13','2','auto','Chevrolet Camaro SS Convertible.jpg',1),(6,'Chevrolet Camaro SS','test1234567','standard',70,'15','2','auto','Chevrolet Camaro SS.jpg',1),(7,'Chevrolet Cruze','test1234567','economy',60,'21','4','auto','Chevrolet Cruze.jpg',1),(8,'Chevrolet Impala','test12345678','economy',60,'23','4','auto','Chevrolet Impala.jpg',1),(9,'Chevrolet Silverado','test12345678','suv',110,'15','4','auto','Chevrolet Silverado.jpg',1),(10,'Chevrolet Spark','test12345678','economy',40,'20','4','auto','Chevrolet Spark.jpg',1),(11,'Chevrolet Suburban','test12345678','suv',110,'15','6','auto','Chevrolet Suburban.jpg',1),(12,'Chrysler 200','test12345678','standard',50,'19','4','auto','Chrysler 200.jpg',1),(13,'Chrysler 300','test12345678','standard',110,'19','4','auto','Chrysler 300.jpg',1),(14,'Corvette Convertible','test12345678','luxury',90,'15','2','auto','Corvette Convertible.jpg',1),(15,'Corvette Stingray','test12345678','luxury',90,'18','2','auto','Corvette Stingray.jpg',3),(16,'Dodge Challenger','test12345678','standard',90,'16','2','auto','Dodge Challenger.jpg',3),(17,'Dodge Journey','test12345678','suv',90,'15','5','auto','Dodge Journey.jpg',3),(18,'Ford Mustang GT Premium','test12345678','luxury',90,'18','2','auto','Ford Mustang GT Premium.jpg',3),(19,'Ford Transit 12 psgr','test12345678','standard',90,'18','12','auto','Ford Transit 12 psgr.jpg',3),(20,'Hyundai Santra Fe','test12345678','economy',50,'22','5','auto','Hyundai Santra Fe.jpg',3),(21,'Infiniti Q50','test12345678','economy',50,'22','5','auto','Infiniti Q50.jpg',3),(22,'Infiniti QX60','test12345678','suv',90,'18','5','auto','Infiniti QX60.jpg',3),(23,'Infiniti QX70','test12345678','suv',95,'17','5','auto','Infiniti QX70.jpg',2),(24,'Infiniti QX80','test12345678','suv',100,'22','5','auto','Infiniti QX80.jpg',1),(25,'Jaguar','test12345678','economy',60,'22','4','auto','Jaguar XJ.jpg',2),(26,'Jeep Compass','test12345678','suv',80,'17','5','auto','Jeep Compass.jpg',2),(27,'Jeep Wrangler Unlimited','test12345678','suv',80,'18','5','auto','Jeep Wrangler Unlimited.jpg',2),(28,'Jeep Wrangler','test12345678','suv',80,'18','5','auto','Jeep Wrangler.jpg',4),(29,'Land Rover Sport','test12345678','suv',80,'18','5','auto','Land Rover Sport.jpg',1),(30,'Mercedes C63 AMG','test12345678','standard',80,'18','5','auto','Mercedes C63 AMG.jpg',2),(31,'Mercedes C300','test12345678','standard',80,'18','5','auto','Mercedes C300.jpg',3),(32,'Mercedes CLA45 AMG','test12345678','standard',80,'18','5','auto','Mercedes CLA45 AMG.jpg',4),(33,'Mercedes E Class','test12345678','standard',70,'20','5','auto','Mercedes E Class.jpg',3),(34,'Mercedes G550','test12345678','suv',80,'18','5','auto','Mercedes G550.jpg',2),(35,'Mercedes GL450','test12345678','suv',80,'18','5','auto','Mercedes GL450.jpg',1),(36,'Mercedes SLK250','test12345678','luxury',70,'18','2','auto','Mercedes SLK250.jpg',2),(37,'Nissan Altima','test12345678','economy',50,'22','2','auto','Nissan Altima.jpg',3),(38,'Nissan Armada','test12345678','suv',80,'16','5','auto','Nissan Armada.jpg',1),(39,'Nissan Frontier Crew Cab','test12345678','suv',90,'16','5','auto','Nissan Frontier Crew Cab.jpg',1),(40,'Nissan NV','test12345678','suv',90,'16','8','auto','Nissan NV.jpg',3),(41,'Ford Mustang','test1234567','luxury',100,'10','2','auto','Ford Mustang GT Premium.jpg',4);
/*!40000 ALTER TABLE `vehicles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-02 13:37:21
