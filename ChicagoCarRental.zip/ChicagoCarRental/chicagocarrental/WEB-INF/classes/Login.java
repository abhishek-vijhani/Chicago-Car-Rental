import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class Login extends HttpServlet{



    public void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
	HttpSession session =  request.getSession();
     String email = request.getParameter("username");
	 String password = request.getParameter("password");
	 String type = request.getParameter("type");
	 int total = MySQLDataStore.LoginUser(email,password,type);
	 if(total==0){
		response.sendRedirect("Home?page=loginerror");
		
	 }
	 else{
		session.setAttribute("uname",email);
		session.setAttribute("utype",type);  
		response.sendRedirect("Home?page=loginsuccess");
	 }
      

    }

    public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
          processRequest(request, response);
    }


    public void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
          processRequest(request, response);
    }


}
