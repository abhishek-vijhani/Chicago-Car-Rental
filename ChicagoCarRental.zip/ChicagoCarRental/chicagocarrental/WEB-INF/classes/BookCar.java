import java.util.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat; 
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.servlet.http.HttpSession;

public class BookCar extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException{
        response.setContentType("text/html");
        PrintWriter pw = response.getWriter();
        Utilities util = new Utilities(pw);
		util.printHtml(getServletContext().getRealPath("headersuccess.html"));

        String id= request.getParameter("id");
       
        String type= request.getParameter("type");
        String name= request.getParameter("name");
       
        String location= request.getParameter("location");
        String mileage=request.getParameter("mileage");
        int passenger=Integer.parseInt(request.getParameter("passenger"));
        String transmission=request.getParameter("transmission");
        String pickupdate= request.getParameter("pickupdate");
        String dropoffdate= request.getParameter("dropoffdate");
		int diffInDays =0;
		try{
		Date pickupdatefinal=new SimpleDateFormat("dd/MM/yyyy").parse(pickupdate); 
		Date dropoffdatefinal=new SimpleDateFormat("dd/MM/yyyy").parse(dropoffdate); 
        diffInDays = (int) (( dropoffdatefinal.getTime()- pickupdatefinal.getTime() ) / (1000 * 60 * 60 * 24));
		}
		catch(Exception e){
		System.out.println(e);
		}

		double total= diffInDays*Double.parseDouble(request.getParameter("price"));
		pw.print("<section class='pricing-table' id='abouts'><div class='container' style=\"background-color: white;\"><div class='row'>");
        pw.print("<div class='contact-details col-md-6 ' >");
				pw.print("<h3>Car Details</h3>");
				pw.print("<table class='table'>");
				pw.print("<tr><td>Model</td><td>"+name+"</td></tr>");
       
        pw.print("<tr><td>Type</td><td>"+type+"</td></tr>");
          pw.print("<tr><td>Transmission</td><td>"+transmission+"</td></tr>");
          pw.print("<tr><td>Mileage</td><td>"+mileage+"</td></tr>");
          pw.print("<tr><td>Seats</td><td>"+passenger+"</td></tr>");
        pw.print("<tr><td>Total Rent</td><td>"+total+"</td></tr>");
        pw.print("<tr><td>Pickup Location</td><td>"+location+"</td></tr>");
        pw.print("<tr><td>Pickup Date</td><td>"+pickupdate+"</td></tr>");
        pw.print("<tr><td>Drop off Date</td><td>"+dropoffdate+"</td></tr>");
		    pw.print("</table>");

				  pw.print("</div>");
           pw.print("<div class='contact-form col-md-6' >");
  				pw.print("<form id='contact-form' method='post' action='StorePayment'>");
          pw.print("<h3>Payment Details</h3>");

  				


  				pw.print("<div class='form-group'>");
  				pw.print("<textarea rows='6' placeholder='Address' class='form-control' name='address' id='address'></textarea>	");
  				pw.print("</div>");

          pw.print("<div class='form-group'>");
  				pw.print("<input type='text' placeholder='Credit Card No' class='form-control' name='CCard' id='creditcard' required>");
  				pw.print("</div>");
          pw.print( "<input type='hidden' name='name' value='"+name+"'><input type='hidden' name='type' value='"+type+"'>"
				
          + "<input type='hidden' name='price' value='" +total+ "'>"
          + "<input type='hidden' name='location' value='" +location+ "'>"
          + "<input type='hidden' name='id' value='" + id + "'>"
					+ "<input type='hidden' name='mileage' value='" + mileage + "'>"
					+ "<input type='hidden' name='passenger' value='" +passenger + "'>"
					+ "<input type='hidden' name='transmission' value='" + transmission + "'>"
          + "<input type='hidden' name='pickupdate' value='" +pickupdate+ "'>"
          + "<input type='hidden' name='dropoffdate' value='" +dropoffdate+ "'>");

  				pw.print("<div id='cf-submit'>");
  				pw.print("<input type='submit'  class='btn btn-transparent' value='Make Payment' style=\"background-color: green;\">");
  				pw.print("</div>");

  				pw.print("</form>");
  				pw.print("</div>");

          pw.print("</div></div></section>");
          pw.print("<div class='clear'></div>");
          util.printHtml(getServletContext().getRealPath("footer.html"));
          }
        }
