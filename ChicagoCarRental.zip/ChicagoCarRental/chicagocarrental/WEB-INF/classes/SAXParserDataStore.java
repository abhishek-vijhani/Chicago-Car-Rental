
import java.io.IOException;
import java.text.ParseException;

import java.util.*;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;




public class SAXParserDataStore extends DefaultHandler {
    Vehicle vehicle;
   static  Map<Integer,Vehicle> vehicles;
    String xmlFileName;
    String elementValueRead;

    
    public SAXParserDataStore(String xmlFileName) {
        this.xmlFileName = xmlFileName;
        vehicles = new HashMap<Integer,Vehicle>();
        parseDocument();
       
    }


    private void parseDocument() {
        SAXParserFactory factory = SAXParserFactory.newInstance();
        try {
            SAXParser parser = factory.newSAXParser();
            parser.parse(xmlFileName, this);
        } catch (ParserConfigurationException e) {
            System.out.println("ParserConfig error");
        } catch (SAXException e) {
            System.out.println("SAXException : xml not well formed");
        } catch (IOException e) {
            System.out.println("IO error");
        }
    }










    @Override
    public void startElement(String str1, String str2, String elementName, Attributes attributes) throws SAXException {

        if (elementName.equalsIgnoreCase("vehicle")) {
            vehicle = new Vehicle();
            vehicle.setId(Integer.valueOf(attributes.getValue("id")));
            
        }

    }

    @Override
    public void endElement(String str1, String str2, String element) throws SAXException {
 
        if (element.equals("vehicle")) {
            vehicles.put(vehicle.getId(),vehicle);
	    return;
        }
        if (element.equalsIgnoreCase("image")) {
            vehicle.setImage(elementValueRead);
	    return;
        }
        if (element.equalsIgnoreCase("name")) {
            vehicle.setName(elementValueRead);
	    return;
        }
		if (element.equalsIgnoreCase("type")) {
            vehicle.setType(elementValueRead);
	    return;
        }
		if (element.equalsIgnoreCase("passengercapacity")) {
            vehicle.setPassengerCapacity(elementValueRead);
	    return;
        }
		if (element.equalsIgnoreCase("mileage")) {
            vehicle.setMileage(elementValueRead);
	    return;
        }
		
		if (element.equalsIgnoreCase("transmission")) {
            vehicle.setTransmission(elementValueRead);
	    return;
        }
       
		if (element.equalsIgnoreCase("registrationnumber")) {
            vehicle.setRegistrationNumber(elementValueRead);
	    return;
        }
       
       
        if(element.equalsIgnoreCase("price")){
            vehicle.setPrice(Integer.parseInt(elementValueRead));
	    return;
        }
		
		if(element.equalsIgnoreCase("locationid")){
            vehicle.setLocationId(Integer.parseInt(elementValueRead));
	    return;
        }

    }

    @Override
    public void characters(char[] content, int begin, int end) throws SAXException {
        elementValueRead = new String(content, begin, end);
    }



}
