import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class DeleteVehicleDetails extends HttpServlet{

     public void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
		 //String registrationnumber = request.getParameter("registrationnumber");
		 int id = Integer.valueOf(request.getParameter("id"));
		MySQLDataStore.deleteVehicleDetails(id);
		/*
		Vehicle v = new Vehicle();
		v.setId(id);
		v.setLocationId(locationid);
		v.setTransmission(transmission);
		v.setRegistrationNumber(registrationnumber);
		v.setPassengerCapacity(passengercapacity);
		v.setMileage(mileage);
		v.setType(type);
		v.setImage(image);
		v.setPrice(price);
		v.setName(name);
		SAXParserDataStore.vehicles.remove(id);
		SAXParserDataStore.vehicles.put(id, v);
		*/
		System.out.println(SAXParserDataStore.vehicles);
		response.sendRedirect("Home?page=loginsuccess");
    }
	
	

   


}
