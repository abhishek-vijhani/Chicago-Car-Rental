

import java.util.ArrayList;
import java.util.List;


public class Vehicle {
    String name;
    int id;
    String image;
String condition;
	String transmission;
	String registrationNumber;
	String passengerCapacity;
	String mileage;
	String type;
    int price;
	int locationId;
    


void setId(int id) {
	this.id = id;
}
void setLocationId(int locationId) {
	this.locationId = locationId;
}


void setTransmission(String transmission) {
	this.transmission = transmission;
}
void setRegistrationNumber(String registrationNumber) {
	this.registrationNumber = registrationNumber;
}
void setPassengerCapacity(String passengerCapacity) {
	this.passengerCapacity = passengerCapacity;
}
void setMileage(String mileage) {
	this.mileage = mileage;
}
void setType(String type) {
	this.type = type;
}


void setImage(String image) {
	this.image = image;
}

void setCondition(String condition) {
	this.condition = condition;
}

void setPrice(int price) {
	this.price = price;
}



void setName(String name) {
	this.name = name;
}

int getId(){
	return id;
}
int getLocationId(){
	return locationId;
}
int getPrice(){
	return price;
}
String getImage(){
	return image;
}

String getName(){
	return name;
}
String getType(){
	return type;
}
String getTransmission(){
	return transmission;
}
String getRegistrationNumber(){
	return registrationNumber;
}
String getPassengerCapacity(){
	return passengerCapacity;
}
String getMileage(){
	return mileage;
}


}
