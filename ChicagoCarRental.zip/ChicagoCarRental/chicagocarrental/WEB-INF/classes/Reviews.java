

import java.util.ArrayList;
import java.util.List;


public class Reviews {
    
	int vehicleid;
    String username;
	int rating;
	String reviewdate;
	String review;
	String vehiclename;
	

void setVehicleId(int vehicleid) {
	this.vehicleid = vehicleid;
}
void setRating(int rating) {
	this.rating = rating;
}

void setUsername(String username) {
	this.username = username;
}
void setReviewdate(String reviewdate) {
	this.reviewdate = reviewdate;
}
void setReview(String review) {
	this.review = review;
}

void setVehicleName(String vehiclename) {
	this.vehiclename = vehiclename;
}

int getRating(){
	return rating;
}
int getVehicleId(){
	return vehicleid;
}
String getUsername(){
	return username;
}
String getReviewdate(){
	return reviewdate;
}
String getReview(){
	return review;
}
String getVehicleName(){
	return vehiclename;
}





}
