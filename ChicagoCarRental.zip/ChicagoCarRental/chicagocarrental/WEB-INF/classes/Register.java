import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class Register extends HttpServlet{

     public void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
		 String name = request.getParameter("name");
		 String email = request.getParameter("email");
		 String password = request.getParameter("password");
		 String license = request.getParameter("license");
		 String type = request.getParameter("type");
		MySQLDataStore.registerUser(name,email,password,license,type);
		response.sendRedirect("Home?page=login");
    }
	
	

   


}
