

import java.util.ArrayList;
import java.util.List;


public class BookingData {
    
    int bookingid;
	int vehicleid;
	int price;
	int userid;
    String pickupdate;
	String vehiclename;
	String dropoffdate;
	
void setBookingId(int bookingid) {
	this.bookingid = bookingid;
}
void setVehicleId(int vehicleid) {
	this.vehicleid = vehicleid;
}
void setPrice(int price) {
	this.price = price;
}
void setUserId(int userid) {
	this.userid = userid;
}
void setPickupdate(String pickupdate) {
	this.pickupdate = pickupdate;
}
void setDropoffdate(String dropoffdate) {
	this.dropoffdate = dropoffdate;
}
void setVehicleName(String vehiclename) {
	this.vehiclename = vehiclename;
}



int getBookingId(){
	return bookingid;
}
int getVehicleId(){
	return vehicleid;
}
int getPrice(){
	return price;
}
int getUserId(){
	return userid;
}

String getPickupdate(){
	return pickupdate;
}
String getDropoffdate(){
	return dropoffdate;
}
String getVehicleName(){
	return vehiclename;
}



}
