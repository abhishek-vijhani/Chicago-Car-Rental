import java.util.ArrayList;
import java.util.List;

	
public class Barchart1Bean {

    String vehicleid;
    String name;
    int count;

	
	public Barchart1Bean()
	{}

    public Barchart1Bean(int count,String vehicleid,String name){
        this.count = count;
		this.vehicleid = vehicleid;
		this.name = name;
    }

	public int getCount() {
		return count;
	}



	public String getName() {
		return name;
	}


	public String getVehicleid() {
		return vehicleid;
	}
	
   
	
}