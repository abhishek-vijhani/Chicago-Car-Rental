import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class Trending extends HttpServlet{

     public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
		   HttpSession session = request.getSession();
			String stype  = (String)session.getAttribute("utype");
			String uname  = (String)session.getAttribute("uname");
			if(stype.equals("customer")){
			PrintWriter pw = response.getWriter();
			Utilities util = new Utilities(pw);
			util.printHtml(getServletContext().getRealPath("headersuccess.html"));
			Map<String,String> mostLiked  = new LinkedHashMap<String,String>();
			mostLiked = MongoDBDataStoreUtilities.mostLikedCars();
			Map<String,String> mostBookedCars  = new LinkedHashMap<String,String>();
			mostBookedCars = MongoDBDataStoreUtilities.mostBookedCars();
			pw.print("<section class='hero-area'>	<div class='container'><div class='row'>");
			pw.print("<div class='col-md-12'><div class='block'>");
			pw.print("<h3> Most Liked Cars </h3>");
			pw.print("<table class='table'>");
			pw.print("<th>Vehicle Name </th>");
			pw.print("<th>Avergae Rating </th>");
			for(Map.Entry m : mostLiked.entrySet()){
				pw.print("<tr><td>"+m.getKey()+"</td>");
				pw.print("<td>"+m.getValue()+"</td></tr>");

				
			}
			pw.print("</table><br>");
			
			pw.print("<h3> Top 5 most booked cars irrespective of ratings </h3>");
			pw.print("<table class='table'>");
			pw.print("<th>Vehicle Name </th>");
			pw.print("<th>Number of times booked </th>");
			for(Map.Entry m : mostBookedCars.entrySet()){
				pw.print("<tr><td>"+m.getKey()+"</td>");
				pw.print("<td>"+m.getValue()+"</td></tr>");
			}
			pw.print("</table></div></div></div></div>");
			
			pw.print("</section>");	
			util.printHtml(getServletContext().getRealPath("footer.html"));
			}
			else{
			response.sendRedirect("Home?page=login");
			}
    }
	
	

   


}
