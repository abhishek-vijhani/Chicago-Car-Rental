import java.util.*;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.servlet.http.HttpSession;

public class ViewItem extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException{
        response.setContentType("text/html");
        PrintWriter pw = response.getWriter();
        Utilities util = new Utilities(pw);
        String id= request.getParameter("id");
        String type= request.getParameter("type");
        String name= request.getParameter("name");
        double total= Double.parseDouble(request.getParameter("price"));
        String location= request.getParameter("location");
        String mileage=request.getParameter("mileage");
        int passenger=Integer.parseInt(request.getParameter("passenger"));
        String transmission=request.getParameter("transmission");
		String finalPickupDate= request.getParameter("pickupdate");
        String finalDropoffDate= request.getParameter("dropoffdate");



		util.printHtml(getServletContext().getRealPath("headersuccess.html"));
		pw.print("<section class='about' id='about'><div class='container'><div class='row'>");
    pw.print("<div class='col-md-1'></div><div class='col-md-8'><h3>" + request.getParameter("name") + "</h3>");



            pw.print("<h5></h5>");
			pw.print("<h5>PRICE: $" + request.getParameter("price") + "</h5><div class='col-md-1'></div></div>");
		pw.print("<div class='col-md-6'><img src='vehicleimage\\"+request.getParameter("image")+ "' class='img-responsive' alt=''></div>");
		pw.print("<div class='col-md-3' style='padding-top: 40px;'><ul style='margin-left: 0px;'>");
			pw.print("<li style='list-style-type: none;'><form method='get' action='BookCar'  style='text-align:center;margin-bottom: -10;'>" + "<input type='hidden' name='name' value='"
					+ request.getParameter("name")+ "'>" + "<input type='hidden' name='type' value='"+type+"'>"
					+ "<input type='hidden' name='maker' value='" +request.getParameter("maker")+ "'>"
          + "<input type='hidden' name='price' value='" +request.getParameter("price")+ "'>"
          + "<input type='hidden' name='id' value='" +request.getParameter("id")+ "'>"
          + "<input type='hidden' name='mileage' value='" + request.getParameter("mileage") + "'>"
					+ "<input type='hidden' name='passenger' value='" + request.getParameter("passenger") + "'>"
					+ "<input type='hidden' name='transmission' value='" + request.getParameter("transmission") + "'>"
					+ "<input type='hidden' name='pickupdate' value='" + finalPickupDate + "'>"
					+ "<input type='hidden' name='dropoffdate' value='" + finalDropoffDate + "'>"
					+ "<input type='hidden' name='location' value='" + request.getParameter("location")+ "'>"
          + "<input type='hidden' name='image' value='" +request.getParameter("image")+ "'>"
					+ "<input type='submit' class='btn btn-main mt-20' value='Book Car' ></form></li>");
			pw.print("<li style='list-style-type: none;'><form method='get' action='WriteReview'  style='text-align:center;margin-bottom: -10;'>" + "<input type='hidden' name='name' value='"
					+ request.getParameter("name")+ "'>" + "<input type='hidden' name='type' value='"+type+"'>"
					+ "<input type='hidden' name='maker' value='" +request.getParameter("maker")+ "'>"
          + "<input type='hidden' name='price' value='" +request.getParameter("price")+ "'>"
          + "<input type='hidden' name='id' value='" +request.getParameter("id")+ "'>"
          + "<input type='hidden' name='mileage' value='" + request.getParameter("mileage") + "'>"
					+ "<input type='hidden' name='passenger' value='" + request.getParameter("passenger") + "'>"
					+ "<input type='hidden' name='transmission' value='" + request.getParameter("transmission") + "'>"
					+ "<input type='hidden' name='pickupdate' value='" + finalPickupDate + "'>"
					+ "<input type='hidden' name='dropoffdate' value='" + finalDropoffDate + "'>"
					+ "<input type='hidden' name='location' value='" + request.getParameter("location") + "'>"
          + "<input type='hidden' name='image' value='" +request.getParameter("image")+ "'>"
					+ "<input type='submit' class='btn btn-main mt-20' value='Write Reviews'></form></li>");
            //pw.print("</ul></div></td>");
            pw.print("<li style='list-style-type: none;'><form method='get' action='ViewReview'  style='text-align:center;margin-bottom: -10;'>" + "<input type='hidden' name='name' value='"
					+ request.getParameter("name")+ "'>" + "<input type='hidden' name='type' value='"+type+"'>"
					+ "<input type='hidden' name='maker' value='" +request.getParameter("maker")+ "'>"
          + "<input type='hidden' name='price' value='" +request.getParameter("price")+ "'>"
          + "<input type='hidden' name='id' value='" +request.getParameter("id")+ "'>"
          + "<input type='hidden' name='mileage' value='" + request.getParameter("mileage") + "'>"
					+ "<input type='hidden' name='passenger' value='" + request.getParameter("passenger") + "'>"
					+ "<input type='hidden' name='transmission' value='" + request.getParameter("transmission") + "'>"
					+ "<input type='hidden' name='pickupdate' value='" + finalPickupDate + "'>"
					+ "<input type='hidden' name='dropoffdate' value='" + finalDropoffDate + "'>"
					+ "<input type='hidden' name='location' value='" + request.getParameter("location") + "'>"
          + "<input type='hidden' name='image' value='" +request.getParameter("image")+ "'>"
					+ "<input type='submit' class='btn btn-main mt-20' value='View Reviews'></form>");
            pw.print("</ul></div>");

        pw.print("<div class='col-md-3'></div></div></div>");
        pw.print("<div class='row'><div class='col-md-2'></div><div class='col-md-8'><h2>Car Details</h2>");
        pw.print("<table class='table'>");

        pw.print("<tr><td>Model</td><td>"+name+"</td></tr>");
      
        pw.print("<tr><td>Type</td><td>"+type+"</td></tr>");
          pw.print("<tr><td>Transmission</td><td>"+transmission+"</td></tr>");
          pw.print("<tr><td>Mileage</td><td>"+mileage+"</td></tr>");
          pw.print("<tr><td>Seats</td><td>"+passenger+"</td></tr>");
        pw.print("<tr><td>Total Rent</td><td>"+total+"</td></tr>");
        pw.print("<tr><td>Pickup Location</td><td>"+location+"</td></tr>");

        pw.print("</table></div><div class='col-md-2'></div></div></section>");


		pw.print("<div class='clear'></div></div>");
		util.printHtml(getServletContext().getRealPath("footer.html"));
    }
}
