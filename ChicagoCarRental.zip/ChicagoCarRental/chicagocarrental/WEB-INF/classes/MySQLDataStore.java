import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


public class MySQLDataStore extends HttpServlet{
	public static Connection getConnection(){
		Connection con=null;
	try{
    Class.forName("com.mysql.jdbc.Driver");  
	con=DriverManager.getConnection("jdbc:mysql://localhost:3306/chicagocarrental","root","root");  
	}
	catch(Exception e)
	{ 
		System.out.println(e);
	}
	return con;
	}
	
	public static void loadVehicles(Map<Integer,Vehicle> vehicles){
		clearTable();
		try{
		Connection con = getConnection();
		Vehicle v = new Vehicle(); ;
		for(Map.Entry m: vehicles.entrySet()){
			v = (Vehicle)m.getValue();
		PreparedStatement stmt=con.prepareStatement("insert into vehicles(vehicleid,name,registrationnumber,type,mileage,price,passengercapacity,transmission,image,locationid) values(?,?,?,?,?,?,?,?,?,?)");  
		stmt.setInt(1,v.getId());
		stmt.setString(2,v.getName());
		stmt.setString(3,v.getRegistrationNumber()); 
		stmt.setString(4,v.getType()); 
		stmt.setString(5,v.getMileage()); 
		stmt.setInt(6,v.getPrice()); 
		stmt.setString(7,v.getPassengerCapacity()); 
		stmt.setString(8,v.getTransmission()); 
		stmt.setString(9,v.getImage());
		stmt.setInt(10,v.getLocationId()); 
  
		stmt.executeUpdate();  
		}
		}
		catch(Exception e){
		System.out.println(e);
		}
	}
	
	public static void clearTable(){
		try{
		Connection con = getConnection();
		Statement stmt=con.createStatement();  
		stmt.executeUpdate("delete from vehicles");  
		}
		catch(Exception e){
		System.out.println(e);
		}
	}
	
	public static void deleteBooking(int bookingid){
		try{
		Connection con = getConnection();
		Statement stmt=con.createStatement();  
		stmt.executeUpdate("delete from bookings where bookingid="+bookingid);  
		}
		catch(Exception e){
		System.out.println(e);
		}
	}
	public static void registerUser(String name,String email,String password,String license, String type){
		try{
		Connection con = getConnection();
		PreparedStatement stmt=con.prepareStatement("insert into user(name,email,password,type,licensenumber) values(?,?,?,?,?)");  
		
		stmt.setString(1,name);
		stmt.setString(2,email); 
		stmt.setString(3,password); 
		stmt.setString(4,type); 
		stmt.setString(5,license); 
  
		stmt.executeUpdate();  
		}
		catch(Exception e){
		System.out.println(e);
		}
	}
	public static void addVehicleDetails(int id, String name,String registrationnumber,int price,String mileage,String type,String passengercapacity,String transmission,String image,int locationid)
	{
		try{
		Connection con = getConnection();
		PreparedStatement stmt=con.prepareStatement("insert into vehicles(vehicleid, name,registrationnumber,type,mileage,price,passengercapacity,transmission,image,locationid) values(?,?,?,?,?,?,?,?,?,?)");  
		stmt.setInt(1,id);
		stmt.setString(2,name);
		stmt.setString(3,registrationnumber); 
		stmt.setString(4,type); 
		stmt.setString(5,mileage); 
		stmt.setInt(6,price); 
		stmt.setString(7,passengercapacity); 
		stmt.setString(8,transmission); 
		stmt.setString(9,image);
		stmt.setInt(10,locationid); 
  
  
		stmt.executeUpdate();  
		}
		catch(Exception e){
		System.out.println(e);
		}
	}
	
	public static void updateVehicleDetails(int id, String name,String registrationnumber,int price,String mileage,String type,String passengercapacity,String transmission,String image,int locationid)
	{
		try{
		Connection con = getConnection();
		Statement stmt=con.createStatement();
		stmt.executeUpdate("update vehicles set name='"+name+"',registrationnumber='"+registrationnumber+"',type='"+type+"',mileage ='"+mileage+"',price ="+price+",passengercapacity='"+passengercapacity+"',transmission='"+transmission+"',image='"+image+"',locationid="+locationid+" where vehicleid ="+id);  
		}
		catch(Exception e){
		System.out.println(e);
		}
	}
	
	public static void deleteVehicleDetails(int id)
	{
		try{
		Connection con = getConnection();
		Statement stmt=con.createStatement();
		stmt.executeUpdate("DELETE FROM vehicles WHERE vehicleid =" +id);  
		}
		catch(Exception e){
		System.out.println(e);
		}
	}
	
	
	public static HashMap<String,Barchart1Bean> barchart1(){
	  HashMap <String,Barchart1Bean> barchart1 = new HashMap<String,Barchart1Bean> ();
	 
  try{
	  
      Connection con = getConnection();
      
	  String selectfromproduct = "select count(bookings.vehicleid) as count, bookings.vehicleid, vehicles.name from bookings left join vehicles on bookings.vehicleid=vehicles.vehicleid group by bookings.vehicleid;";
        
      PreparedStatement pst =
      con.prepareStatement(selectfromproduct);
	  ResultSet rs = pst.executeQuery();
	  while(rs.next())
	  {
		int count = rs.getInt("count");
		 String vehicleid = rs.getString("vehicleid");
		 String name = rs.getString("name");
		 Barchart1Bean barchart1bean = new Barchart1Bean(count,vehicleid,name);
		 barchart1.put(vehicleid,barchart1bean);	
	  }
	  
}
catch(Exception e){System.out.println(e);}
 return barchart1;
}


public static HashMap<String,Integer> barchart2(){
	  HashMap <String,Integer> barchart2 = new HashMap<String,Integer> ();
	 
  try{
	  
      Connection con = getConnection();
      
	  String selectfromproduct = "Select count(vehicleid) as total , type from vehicles group by type;";
        
      PreparedStatement pst =
      con.prepareStatement(selectfromproduct);
	  ResultSet rs = pst.executeQuery();
	  while(rs.next())
	  {
		int total = rs.getInt("total");
		 String type = rs.getString("type");
		 barchart2.put(type,total);	
	  }
	  
}
catch(Exception e){System.out.println(e);}
 return barchart2;
}
	
	
		public static int getUseridFromEmail(String email){
		int id =0;
		try{
		Connection con = getConnection();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("select userid from user where email='"+email+"'");  
		
		while(rs.next()) {
			id = rs.getInt("userid");
		}
		
		con.close();  
		}catch(Exception e){ System.out.println(e);}  
		return id;
	} 
	
	public static Map<Integer,BookingData> getBookings(int userid){
		Map<Integer,BookingData> bookingMap = new HashMap<Integer,BookingData>();
		try{
		Connection con = getConnection();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("select * from bookings left join vehicles on bookings.vehicleid = vehicles.vehicleid where userid="+userid);  
		BookingData bd;
		while(rs.next()) {
			bd = new BookingData();
			
			bd.setUserId(rs.getInt("userid"));
			bd.setPrice(rs.getInt("price"));
			bd.setDropoffdate(rs.getString("dropoffdate"));
			bd.setPickupdate(rs.getString("pickupdate"));
			bd.setVehicleId(rs.getInt("vehicleid"));
			bd.setVehicleName(rs.getString("name"));
			bookingMap.put(rs.getInt("bookingid"), bd);
			
		}
		
		con.close();  
		}catch(Exception e){ System.out.println(e);}  
		return bookingMap;
	} 
	
		public static Map<Integer,BookingData> getBookingsDetails(int bookingid){
		Map<Integer,BookingData> bookingMap = new HashMap<Integer,BookingData>();
		try{
		Connection con = getConnection();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("select * from bookings left join vehicles on bookings.vehicleid = vehicles.vehicleid where bookingid="+bookingid);  
		BookingData bd;
		while(rs.next()) {
			bd = new BookingData();
			
			bd.setUserId(rs.getInt("userid"));
			bd.setPrice(rs.getInt("price"));
			bd.setDropoffdate(rs.getString("dropoffdate"));
			bd.setPickupdate(rs.getString("pickupdate"));
			bd.setVehicleId(rs.getInt("vehicleid"));
			bd.setVehicleName(rs.getString("name"));
			bookingMap.put(rs.getInt("bookingid"), bd);
			
		}
		
		con.close();  
		}catch(Exception e){ System.out.println(e);}  
		return bookingMap;
	}
	
	//
	
		public static Map<Integer,Vehicle> getAllVehicles(){
		Map<Integer,Vehicle> vehicleMap = new HashMap<Integer,Vehicle>();
		try{
		Connection con = getConnection();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("select * from vehicles");  
		Vehicle bd;
		while(rs.next()) {
			bd = new Vehicle();
			bd.setName(rs.getString("name"));
			vehicleMap.put(rs.getInt("vehicleid"), bd);
			
		}
		
		con.close();  
		}catch(Exception e){ System.out.println(e);}  
		return vehicleMap;
	}
	//
	
	public static ArrayList<Integer> getNotAvailableVehicles(String pdate){
		ArrayList<Integer>  bookingList = new ArrayList<Integer>();
		try{
		Date date0=new SimpleDateFormat("dd/MM/yyyy").parse(pdate);  
		long check0 =date0.getTime();
	
		
		
		Connection con = getConnection();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("select vehicleid,dropoffdate from bookings");  
		while(rs.next()) {
			String ddate = rs.getString("dropoffdate");
			Date date1=new SimpleDateFormat("dd/MM/yyyy").parse(ddate);  
			long check1 =date1.getTime();
			if(check1>check0){
				bookingList.add(rs.getInt("vehicleid"));
				
			}
			else{
			
			
			}
			
		}
		
		con.close();  
		}catch(Exception e){ System.out.println(e);}  
		System.out.println("aa"+bookingList);
		return bookingList;
	}
	
		public static int addBooking(int id,String pickupdate,String dropoffdate,int total, String email){
			int userid = getUseridFromEmail(email);
		int last_inserted_id=0;
		try{
		Connection con = getConnection();
		PreparedStatement stmt=con.prepareStatement("insert into bookings(vehicleid,pickupdate,dropoffdate,price,userid) values(?,?,?,?,?)",Statement.RETURN_GENERATED_KEYS);  
		
		stmt.setInt(1,id);
		stmt.setString(2,pickupdate); 
		stmt.setString(3,dropoffdate); 
		stmt.setInt(4,total); 
		stmt.setInt(5,userid);
		
		stmt.executeUpdate();
		ResultSet rs = stmt.getGeneratedKeys();
		
        if(rs.next())
        {
                  last_inserted_id   = rs.getInt(1);
        }
		
		}
		catch(Exception e){
		System.out.println(e);
		}
		return last_inserted_id;
	}
	
	public static int LoginUser(String email,String password,String type){
		int total =0;
		try{
		Connection con = getConnection();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("select count(*) as total from user where email='"+email+"' And password ='"+password+"' And type='"+type+"'");  
		
		while(rs.next()) {
			total = rs.getInt("total");
		}
		
		con.close();  
		}catch(Exception e){ System.out.println(e);}  
		return total;
	} 

	public static ArrayList<String> getLocations(String key){
		ArrayList<String> locations = new ArrayList<String> ();
		try{
		Connection con = getConnection();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("select locationname from location where locationname like '"+key+"%'");  
		
		while(rs.next()) {
			System.out.println(rs.getString("locationname"));
			 locations.add(rs.getString("locationname"));
		}
		
		con.close();  
		}catch(Exception e){ System.out.println(e);}  
		return locations;
	}  
	
	public static int getLocationsid(String key){
		int id=0;
		try{
		Connection con = getConnection();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("select locationid from location where locationname = '"+key+"'");  
		
		while(rs.next()) {
			id = rs.getInt("locationid");
		}
		
		con.close();  
		}catch(Exception e){ System.out.println(e);}  
		return id;
	}
   


}
