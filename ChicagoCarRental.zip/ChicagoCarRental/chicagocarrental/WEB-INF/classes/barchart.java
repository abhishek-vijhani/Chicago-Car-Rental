import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Map.Entry;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class barchart extends HttpServlet{

     public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		Utilities util = new Utilities(pw);
		HttpSession session =  request.getSession();
		String username=(String)session.getAttribute("uname"); 
		util.printHtml(getServletContext().getRealPath("headersuccessmanager.html"));
		
		HashMap<String, Object> temp = new HashMap<String, Object>();
		
		
		
		
		
		
		
	
pw.print("<head>");



pw.println("<script type='text/javascript' src='https://www.gstatic.com/charts/loader.js'></script> ");
		    pw.println("<script type='text/javascript'>");
      pw.println("google.charts.load('current', {'packages':['bar']});");
      pw.println("google.charts.setOnLoadCallback(drawChart);");

      pw.println("function drawChart() {");
        pw.println("var data = google.visualization.arrayToDataTable([");
          pw.println("['Vehicle Name', 'Count'],");
		  String name = "";
	 int count = 0;
		  
		  temp.putAll(MySQLDataStore.barchart1());
			for (Entry<String, Object> entry : temp.entrySet()) {
					
					Barchart1Bean tempObject = (Barchart1Bean) entry.getValue();

				  name = tempObject.getName();
				   count = tempObject.getCount();
				   
				   
				   pw.println("[' " +name+ " ', "+count+ "],");
				   
			}
		  	   
         
       pw.println(" ]);");

      pw.println("  var options = {");
          pw.println("  title: 'Bar Chart of the Most Popular Car Booked',");
        pw.println("  bars: 'vertical' // Required for Material Bar Charts.");
       pw.println(" };");

       pw.println(" var chart = new google.charts.Bar(document.getElementById('barchart_material'));");

        pw.println("chart.draw(data, google.charts.Bar.convertOptions(options));");
     pw.println(" }");
	 pw.println("</script>");

pw.print("</head>");




			
pw.print("<section class='hero-area'>	<div class='container'><div class='row'>");
	pw.println("<div id='barchart_material'></div>");
	pw.print("</div></div></div></div>");
	pw.print("</section>");	
			
			
		/*
			pw.print("<section class='team-skills section-sm' id='skills'><div class='container'><div class='row'>");
		pw.print("<div class='title text-center'>Bar Chart of the Most Popular Car Booked<div class='border'></div></div>");
		pw.print("<div class='col-md-12'>");
		
		pw.println("<div id='barchart_material'></div>");

		
		pw.print("</div>");
		pw.print("</div>");
		pw.print("</div>   	<!-- End container -->");
		pw.print("</section>   <!-- End section -->");
		
		*/
	


		pw.print("<div class='clear'></div>");
		util.printHtml(getServletContext().getRealPath("footer.html"));
		}
    }
	
	
