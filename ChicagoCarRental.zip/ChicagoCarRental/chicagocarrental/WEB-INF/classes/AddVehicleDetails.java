import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class AddVehicleDetails extends HttpServlet{

     public void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
		 String name = request.getParameter("name");
		 String registrationnumber = request.getParameter("registrationnumber");
		 int price = Integer.valueOf(request.getParameter("price"));
		 int id = Integer.valueOf(request.getParameter("id"));
		 String mileage = request.getParameter("mileage");
		 String type = request.getParameter("type");
		 String passengercapacity =  request.getParameter("passengercapacity");
		 String transmission =  request.getParameter("transmission");
		 String image =  request.getParameter("image");
		 int locationid = Integer.valueOf(request.getParameter("locationid"));
		MySQLDataStore.addVehicleDetails(id,name,registrationnumber,price,mileage,type,passengercapacity,transmission,image,locationid);
		Vehicle v = new Vehicle();
		v.setId(id);
		v.setLocationId(locationid);
		v.setTransmission(transmission);
		v.setRegistrationNumber(registrationnumber);
		v.setPassengerCapacity(passengercapacity);
		v.setMileage(mileage);
		v.setType(type);
		v.setImage(image);
		v.setPrice(price);
		v.setName(name);
		SAXParserDataStore.vehicles.put(id, v);
		System.out.println(SAXParserDataStore.vehicles);
		response.sendRedirect("Home?page=loginsuccess");
    }
	
	

   


}
