import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class AddReview extends HttpServlet{

     public void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
		   HttpSession session = request.getSession();
			String stype  = (String)session.getAttribute("utype");
			
			if(stype.equals("customer")){
			String reviewDate = request.getParameter("reviewdate");
			String review = request.getParameter("review");
			String uname = request.getParameter("uname");
			String vehiclename = request.getParameter("vehiclename");
			int rating = Integer.valueOf(request.getParameter("rating"));
			int vehicleid = Integer.valueOf(request.getParameter("vehicleid"));
			PrintWriter pw = response.getWriter();
			Utilities util = new Utilities(pw);
			Reviews r = new Reviews();
			r.setVehicleId(vehicleid);
			r.setRating(rating);
			r.setUsername(uname);
			r.setReviewdate(reviewDate);
			r.setReview(review);
			r.setVehicleName(vehiclename);
			MongoDBDataStoreUtilities.insertReview(r);
			response.sendRedirect("Home");
			}
			else{
			response.sendRedirect("Home?page=login");
			}
    }
	
	

   


}
