import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class AddVehicle extends HttpServlet{

     public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
		   HttpSession session = request.getSession();
			String stype  = (String)session.getAttribute("utype");
			if(stype.equals("manager")){
			PrintWriter pw = response.getWriter();
			Utilities util = new Utilities(pw);
			util.printHtml(getServletContext().getRealPath("headersuccessmanager.html"));
			util.generateAddVehicleHtml();
			util.printHtml(getServletContext().getRealPath("footer.html"));
			}
			else{
			response.sendRedirect("Home?page=login");
			}
    }
	
	

   


}
