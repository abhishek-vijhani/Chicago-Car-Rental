import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class Logout extends HttpServlet{



    public void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
	HttpSession session =  request.getSession();
       session.invalidate();  
      response.sendRedirect("Home?page=logout");

    }

    public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
          processRequest(request, response);
    }


    public void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
          processRequest(request, response);
    }


}
