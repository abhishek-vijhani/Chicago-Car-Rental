import java.util.*;
import java.text.*;
import java.io.*;
import java.net.*;
import com.mongodb.*;

public class MongoDBDataStoreUtilities{

	public static MongoClient getConnection(){
		MongoClient mongo=null;
		try{
			
			mongo = new MongoClient("localhost",27017);
		}
		catch(Exception e ){
		System.out.println("Exception"+e);
		}
		return mongo;
	}
	public static void insertReview(Reviews review){
		try{
				int rating = Integer.valueOf(review.getRating());
				String vehicleid = String.valueOf(review.getVehicleId());
				String vehiclename = review.getVehicleName();
				String username =review.getUsername();
				String reviewdate =review.getReviewdate();
				String rreview =review.getReview();
				MongoClient mongo = getConnection();
				DB db = mongo.getDB("chicagocarrental");
				BasicDBObject d = new BasicDBObject("ctitle","chicagocarrentalreviews")
				.append("vehicleid",vehicleid)
				.append("vehiclename",vehiclename)
				.append("rating",rating)
				.append("username",username)
				.append("reviewdate",reviewdate)
				.append("review",rreview);
				DBCollection collection = db.getCollection("chicagocarrentalreviews");
				collection.insert(d);
		}
		catch(Exception e){
			System.out.println("Exception"+e);
		}	
	}
	
	public static ArrayList<Reviews> getReviews( int vehicleid){
		ArrayList<Reviews> reviews = new ArrayList<Reviews>();
		MongoClient mongo = getConnection();
		DB db = mongo.getDB("chicagocarrental");
		DBCollection collection = db.getCollection("chicagocarrentalreviews");
		BasicDBObject query = new BasicDBObject();
		String vid = String.valueOf(vehicleid);
		query.put("vehicleid",vid);
		DBCursor dbCursor = collection.find(query);
		DBObject o;
		
		while(dbCursor.hasNext()){
				Reviews r = new Reviews();
				o= dbCursor.next();
				r.setRating((int)o.get("rating"));
				r.setUsername((String)o.get("username"));
				r.setReviewdate((String)o.get("reviewdate"));
				r.setReview((String)o.get("review"));
				reviews.add(r);
		}
		System.out.println(reviews);
		return reviews;
	}
	
	public static Map<String,String> mostLikedCars(){
			
		Map<String,String> mostLiked  = new LinkedHashMap<String,String>();
		MongoClient mongo = getConnection();
		DB db = mongo.getDB("chicagocarrental");
		DBCollection collection = db.getCollection("chicagocarrentalreviews");
		DBObject group = new BasicDBObject("$group",new BasicDBObject("_id","$vehiclename").append("rating",new BasicDBObject("$avg","$rating")));
		DBObject sort = new BasicDBObject("$sort",new BasicDBObject("rating",-1));
		DBObject limit = new BasicDBObject("$limit",5);
		AggregationOutput output = collection.aggregate(group,sort,limit);
		for(DBObject result:output.results()){
			
			String vehicleName = (String)result.get("_id");
			String averageRating =String.valueOf(result.get("rating"));
			Double rating = (double)result.get("rating");
			if(rating>3){
			mostLiked.put(vehicleName,averageRating);
			}
		}
		return mostLiked;
	}
	
	public static Map<String,String> mostBookedCars(){
	Map<String,String> mostBookedCars  = new LinkedHashMap<String,String>();
	MongoClient mongo = getConnection();
	DB db = mongo.getDB("chicagocarrental");
	DBCollection collection = db.getCollection("chicagocarrentalreviews");
	DBObject group = new BasicDBObject("$group",new BasicDBObject("_id","$vehiclename").append("carBooked",new BasicDBObject("$sum",1)));
	DBObject sort = new BasicDBObject("$sort",new BasicDBObject("carBooked",-1));
	DBObject limit = new BasicDBObject("$limit",5);
	AggregationOutput output = collection.aggregate(group,sort,limit);
		for(DBObject result:output.results()){

			String vehiclename = (String)result.get("_id");
			String carBooked =String.valueOf(result.get("carBooked"));
			mostBookedCars.put(vehiclename,carBooked);
		}
		return mostBookedCars;
	}
}