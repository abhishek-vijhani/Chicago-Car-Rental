import java.util.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat; 
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.servlet.http.HttpSession;

public class StorePayment extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException{
		HttpSession session = request.getSession();
		String email =(String)session.getAttribute("uname");
        response.setContentType("text/html");
        PrintWriter pw = response.getWriter();
        Utilities util = new Utilities(pw);
		util.printHtml(getServletContext().getRealPath("headersuccess.html"));

        int id= Integer.valueOf(request.getParameter("id"));
        String pickupdate= request.getParameter("pickupdate");
        String dropoffdate= request.getParameter("dropoffdate");
		int diffInDays =0;
		try{
		Date pickupdatefinal=new SimpleDateFormat("dd/MM/yyyy").parse(pickupdate); 
		Date dropoffdatefinal=new SimpleDateFormat("dd/MM/yyyy").parse(dropoffdate); 
        diffInDays = (int) (( dropoffdatefinal.getTime()- pickupdatefinal.getTime() ) / (1000 * 60 * 60 * 24));
		}
		catch(Exception e){
		System.out.println(e);
		}
		double totalpre= Double.parseDouble(request.getParameter("price"));
		int total = (int)totalpre;
		int bookingid =MySQLDataStore.addBooking(id,pickupdate,dropoffdate,total,email);
		pw.print("<section class='pricing-table' id='abouts'><div class='container' style=\"background-color: white;\"><div class='row'>");
        pw.print("<div class='contact-details col-md-6 ' >");
		pw.print("<h3>Payment Success. Your Booking Number is:"+bookingid+"</h3>");
        pw.print("</div></div></section>");
        pw.print("<div class='clear'></div>");
        util.printHtml(getServletContext().getRealPath("footer.html"));
          }
        }
