import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

public class DealMatch extends HttpServlet
{
	String TOMCAT_HOME = System.getProperty("catalina.home");
	PrintWriter pw;
	DealMatch(PrintWriter pwobject){
	this.pw = pwobject;
	}
    public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
    {

	}
	public void generateDealContent(){
		try{
		
		pw.print("<h3>Offers/Tweets </h3>");
		Map<Integer, Vehicle> vehiclesMap = new HashMap<Integer, Vehicle>();
		Map<Integer, Vehicle> foundVehicleMap = new HashMap<Integer, Vehicle>();
		int count =0;
		vehiclesMap = MySQLDataStore.getAllVehicles();
		Vehicle v ;
		Vehicle vFound ;
		String vehicleName ="";
		for(Map.Entry m : vehiclesMap.entrySet()){
			v = (Vehicle)m.getValue();
			vehicleName = v.getName();
			BufferedReader r = new BufferedReader(new FileReader(new File(TOMCAT_HOME+"\\webapps\\chicagocarrental\\DealMatches.txt")));
			String line = r.readLine();
			
			if(line==null){
				pw.print("No offers found");
				break;
			}
			else{
				do{
					if(line.contains(vehicleName))
					{
						
						pw.print(line+"<br>");
						
						count++;
						foundVehicleMap.put(count,v);
						
					}
				}while((line=r.readLine())!= null);
				
			}			
		}
		if(foundVehicleMap.isEmpty()==true){
			pw.print("No offers found");		
		}
		
	
	
	}
	catch(Exception e){
		System.out.println(e);
	}
	
	}
}