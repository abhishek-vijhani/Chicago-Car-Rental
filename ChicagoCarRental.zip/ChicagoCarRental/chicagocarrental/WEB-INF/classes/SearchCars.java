import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class SearchCars extends HttpServlet{

     public void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		Utilities util = new Utilities(pw);
		HttpSession session =  request.getSession();
		String username=(String)session.getAttribute("uname"); 
		if(username == null){
			response.sendRedirect("Home?page=login");
		}
		else{
			String pickupLocation = request.getParameter("pickuplocation");
			String pickupDate = request.getParameter("pickupdate");
			String pickupMonth = request.getParameter("pickupmonth");
			String pickupYear = request.getParameter("pickupyear");
			String finalPickupDate = pickupDate+"/"+pickupMonth+"/"+pickupYear;
			String dropoffDate = request.getParameter("dropoffdate");
			String dropoffMonth = request.getParameter("dropoffmonth");
			String dropoffYear = request.getParameter("dropoffyear");
			String finalDropoffDate = dropoffDate+"/"+dropoffMonth+"/"+dropoffYear;
			String carType = request.getParameter("cartype");
			int locationid = MySQLDataStore.getLocationsid(pickupLocation);
			Map<Integer,Vehicle> vehicles = new HashMap<Integer,Vehicle>();
			vehicles = SAXParserDataStore.vehicles;
			util.printHtml(getServletContext().getRealPath("headersuccess.html"));
		
			pw.print("<section class='pricing-table' id='pricing'><div class='container'><div class='row'>");
		pw.print("<div class='entry'><table id='bestseller'>");
		int i = 1;
			ArrayList<Integer>  bookingList = new ArrayList<Integer>();
			bookingList = MySQLDataStore.getNotAvailableVehicles(finalPickupDate);
		for (Map.Entry m : vehicles.entrySet()) {
			Vehicle vehicle = (Vehicle)m.getValue();
				if(vehicle.getLocationId()==locationid && vehicle.getType().equals(carType) ) 
				{
					if(bookingList.contains(vehicle.getId())){
						// This vehicle is not available
					}
					else{
					
			pw.print("<div class='col-md-4 col-sm-6 col-xs-12' ><div class='pricing-item' style='padding-left: 20px;padding-top: 10px;padding-bottom: 20px;padding-right: 20px;text-align:center; '>");
			pw.print("<div class='price-title' style='padding-top: 10px;padding-bottom: 10px;text-align:center;'>"+
							"<h3>Vehicle</h3>"+
							"<strong >$" + vehicle.getPrice() + "</strong>"+
							"<p>"+ vehicle.getName() +"</p></div>");


			pw.print("<ul>");

			pw.print("<img src= 'vehicleimage\\"+vehicle.getImage()+ "' alt='' style='width: 200px; height: 200px; list-style-type: none; display: block; margin-left: auto; margin-right: auto'/>");
			pw.print("<form method='get' action='BookCar'>" + "<input type='hidden' name='name' value='"
					+ vehicle.getName() + "'>" + "<input type='hidden' name='type' value='"+vehicle.getType()+"'>"
					+ "<input type='hidden' name='image' value='" + vehicle.getImage() + "'>"
					+ "<input type='hidden' name='id' value='" + vehicle.getId() + "'>"
					+ "<input type='hidden' name='price' value='" + vehicle.getPrice() + "'>"
					+ "<input type='hidden' name='mileage' value='" + vehicle.getMileage() + "'>"
					+ "<input type='hidden' name='location' value='" + pickupLocation + "'>"
					+ "<input type='hidden' name='passenger' value='" + vehicle.getPassengerCapacity() + "'>"
					+ "<input type='hidden' name='transmission' value='" + vehicle.getTransmission() + "'>"
					+ "<input type='hidden' name='pickupdate' value='" + finalPickupDate + "'>"
					+ "<input type='hidden' name='dropoffdate' value='" + finalDropoffDate + "'>"
					+ "<input type='submit' class='btn btn-main' value='Book Car' style='margin-top: 3%;' ></form>");
			pw.print("<form method='get' action='ViewItem'>" + "<input type='hidden' name='name' value='"
					+  vehicle.getName() + "'>" + "<input type='hidden' name='type' value='"+vehicle.getType()+"'>"
					
					+ "<input type='hidden' name='image' value='" + vehicle.getImage() + "'>"
					+ "<input type='hidden' name='id' value='" + vehicle.getId() + "'>"
					+ "<input type='hidden' name='price' value='" + vehicle.getPrice() + "'>"
					+ "<input type='hidden' name='mileage' value='" + vehicle.getMileage() + "'>"
					+ "<input type='hidden' name='location' value='" + pickupLocation + "'>"
					+ "<input type='hidden' name='passenger' value='" + vehicle.getPassengerCapacity() + "'>"
					+ "<input type='hidden' name='transmission' value='" + vehicle.getTransmission() + "'>"
					+ "<input type='hidden' name='pickupdate' value='" + finalPickupDate + "'>"
					+ "<input type='hidden' name='dropoffdate' value='" + finalDropoffDate + "'>"
					+ "<input type='submit' class='btn btn-main'  style='margin-top: 3%;' value='View Car'></form>");

			pw.print("<form method='get' action='ViewReview'>" + "<input type='hidden' name='name' value='"
					+  vehicle.getName() + "'>" + "<input type='hidden' name='type' value='"+vehicle.getType()+"'>"
					
					+ "<input type='hidden' name='image' value='" + vehicle.getImage() + "'>"
					+ "<input type='hidden' name='id' value='" + vehicle.getId() + "'>"
					+ "<input type='hidden' name='price' value='" + vehicle.getPrice() + "'>"
					+ "<input type='hidden' name='mileage' value='" + vehicle.getMileage() + "'>"
					+ "<input type='hidden' name='location' value='" + pickupLocation + "'>"
					+ "<input type='hidden' name='passenger' value='" + vehicle.getPassengerCapacity() + "'>"
					+ "<input type='hidden' name='transmission' value='" + vehicle.getTransmission() + "'>"
					+ "<input type='hidden' name='pickupdate' value='" + finalPickupDate + "'>"
					+ "<input type='hidden' name='dropoffdate' value='" + finalDropoffDate + "'>"
					+ "<input type='submit' class='btn btn-main' value='View Review' style='margin-top: 3%;'></form>");
					
			pw.print("<form method='get' action='WriteReview'>" + "<input type='hidden' name='name' value='"
					+  vehicle.getName() + "'>" + "<input type='hidden' name='type' value='"+vehicle.getType()+"'>"
					
					+ "<input type='hidden' name='image' value='" + vehicle.getImage() + "'>"
					+ "<input type='hidden' name='id' value='" + vehicle.getId() + "'>"
					+ "<input type='hidden' name='price' value='" + vehicle.getPrice() + "'>"
					+ "<input type='hidden' name='mileage' value='" + vehicle.getMileage() + "'>"
					+ "<input type='hidden' name='location' value='" + pickupLocation + "'>"
					+ "<input type='hidden' name='passenger' value='" + vehicle.getPassengerCapacity() + "'>"
					+ "<input type='hidden' name='transmission' value='" + vehicle.getTransmission() + "'>"
					+ "<input type='hidden' name='pickupdate' value='" + finalPickupDate + "'>"
					+ "<input type='hidden' name='dropoffdate' value='" + finalDropoffDate + "'>"
					+ "<input type='submit' class='btn btn-main' value='Write Review' style='margin-top: 3%;'></form>");
			pw.print("</ul></div></div>");
				}
		}
		}// if ends

		pw.print("</table></div></div></section>");
		pw.print("<div class='clear'></div></div>");
		util.printHtml(getServletContext().getRealPath("footer.html"));
		}
    }
	
	

   


}
