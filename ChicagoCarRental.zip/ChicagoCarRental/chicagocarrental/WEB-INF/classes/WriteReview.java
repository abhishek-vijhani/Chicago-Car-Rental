import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class WriteReview extends HttpServlet{

     public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
		   HttpSession session = request.getSession();
			String stype  = (String)session.getAttribute("utype");
			String uname  = (String)session.getAttribute("uname");
			if(stype.equals("customer")){
			PrintWriter pw = response.getWriter();
			Utilities util = new Utilities(pw);
			util.printHtml(getServletContext().getRealPath("headersuccess.html"));
			String name = request.getParameter("name");
			String price = request.getParameter("price");
			String id = request.getParameter("id");
			String transmission = request.getParameter("transmission");
			pw.print("<section class='hero-area'>	<div class='container'><div class='row'>");
			pw.print("<div class='col-md-12'><div class='block'><form method = 'post' action ='AddReview' >");
			pw.print("<table>");
			pw.print("<tr><td> Name</td><td>"+name+"</td></tr>");
			pw.print("<tr><td> Price</td><td>"+price+"</td></tr>");
			pw.print("<tr><td> transmission </td><td>"+transmission+"</td></tr>");
			pw.print("<tr><td> UserName</td><td>"+uname+"</td></tr>");
			pw.print("<input type ='text' name='vehicleid' value ='"+id+"' hidden>");
			pw.print("<input type ='text' name='vehiclename' value ='"+name+"' hidden>");
			pw.print("<input type ='text' name='uname' value ='"+uname+"' hidden>");
			pw.print("<tr><td>Date</td><td><input type ='text' name='reviewdate' style='color: black;' placeholder ='DD/MM/YYYY' required></td></tr>");
			pw.print("<tr><td> Rating</td><td><select name='rating' style='color: black;'><option value='1'>1</option>");
			pw.print("<option value='2'>2</option>");
			pw.print("<option value='3'>3</option>");
			pw.print("<option value='4'>4</option>");
			pw.print("<option value='5'>5</option></select></td></tr>");
			pw.print("<tr><td>Review</td><td><input type ='textarea' name='review' style='color: black;' required></td></tr>");
			pw.print("<tr><td style='padding: 10% 20% 0; color:black;'><input type='submit' value='submit'></input></td></tr>");
			pw.print("</table></form></div></div></div></div>");
			pw.print("</section>");	
	
			util.printHtml(getServletContext().getRealPath("footer.html"));
			}
			else{
			response.sendRedirect("Home?page=login");
			}
    }
	
	

   


}
