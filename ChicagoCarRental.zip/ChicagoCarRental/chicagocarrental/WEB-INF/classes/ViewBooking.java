import java.util.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat; 
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.servlet.http.HttpSession;

public class ViewBooking extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException{
		HttpSession session = request.getSession();
		String email =(String)session.getAttribute("uname");
        response.setContentType("text/html");
        PrintWriter pw = response.getWriter();
        Utilities util = new Utilities(pw);
		util.printHtml(getServletContext().getRealPath("headersuccess.html"));
		int userid =MySQLDataStore.getUseridFromEmail(email);
		int bid = Integer.valueOf(request.getParameter("bid"));
		Map<Integer,BookingData> bookingMap = new HashMap<Integer, BookingData>();
		bookingMap = MySQLDataStore.getBookingsDetails(bid);
		pw.print("<section class='pricing-table' id='abouts'><div class='container' style=\"background-color: white;\"><div class='row'>");
        pw.print("<div class='contact-details col-md-6 ' >");
		pw.print("<h3>Bookings</h3>");
		pw.print("<table class='table'>");
		pw.print("<tr><th>BookingId</th>");
		pw.print("<th>VehicleName</th>");
		pw.print("<th>Pickup Date</th>");
		pw.print("<th>Dropoff Date</th>");
		pw.print("<th>Charges</th></tr>");
		BookingData bd ;
		for(Map.Entry m : bookingMap.entrySet()){
			bd = (BookingData)m.getValue();
			pw.print("<tr>");
			pw.print("<td>"+(Integer)m.getKey()+"</td>");
			pw.print("<td>"+bd.getVehicleName()+"</td>");
			pw.print("<td>"+bd.getPickupdate()+"</td>");
			pw.print("<td>"+bd.getDropoffdate()+"</td>");
			pw.print("<td>"+bd.getPrice()+"</td>");
			pw.print("</tr>");
		}
		pw.print("</table>");
			pw.print("</div></div></section>");
        pw.print("<div class='clear'></div>");
        util.printHtml(getServletContext().getRealPath("footer.html"));
          }
        }
