import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class ViewReview extends HttpServlet{

     public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
		   HttpSession session = request.getSession();
			String stype  = (String)session.getAttribute("utype");
			String uname  = (String)session.getAttribute("uname");
			if(stype.equals("customer")){
			PrintWriter pw = response.getWriter();
			Utilities util = new Utilities(pw);
			int vehicleid =Integer.valueOf(request.getParameter("id"));
			util.printHtml(getServletContext().getRealPath("headersuccess.html"));
			ArrayList<Reviews> reviews = new ArrayList<Reviews>();
			reviews = MongoDBDataStoreUtilities.getReviews(vehicleid);
			Reviews r = null;
			pw.print("<section class='pricing-table' id='abouts'><div class='container' style=\"background-color: white;\"><div class='row'>");
			pw.print("<div class='contact-details col-md-6 ' >");
			pw.print("<h3>Reviews</h3>");
		
			for(Reviews rr: reviews){
				r = rr;
				int rating = r.getRating();
				
				String username =r.getUsername();
				String reviewdate =r.getReviewdate();
				String review =r.getReview();
			
			pw.print("<table>");
			pw.print("<tr><td> VehicleID</td><td>"+vehicleid+"</td></tr>");
			pw.print("<tr><td> Rating</td><td>"+rating+"</td></tr>");
			pw.print("<tr><td> Review Date </td><td>"+reviewdate+"</td></tr>");
			pw.print("<tr><td> UserName</td><td>"+username+"</td></tr>");
			pw.print("<tr><td> Review</td><td>"+review+"</td></tr>");
			pw.print("</table><br>");
			}
			pw.print("</div></div></section>");
			pw.print("<div class='clear'></div>");
	
			util.printHtml(getServletContext().getRealPath("footer.html"));
			}
			else{
			response.sendRedirect("Home?page=login");
			}
    }
	
	

   


}
