import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.google.gson.Gson;


public class AjaxUtility extends HttpServlet{

     public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
		  response.setContentType("application/json");
		 String key = (String)request.getParameter("search");
		 if(key.equals("")){
			 String json = new Gson().toJson("");
			PrintWriter pw = response.getWriter();
			pw.print(json);
		 }
		 else{
		 System.out.println("output"+key);
		ArrayList<String> locations = new ArrayList<String> ();
		locations= MySQLDataStore.getLocations(key);
		System.out.println(locations);
		String json = new Gson().toJson(locations);
		PrintWriter pw = response.getWriter();
		pw.print(json);
		 }
    }
	
	

   


}
