import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class Utilities extends HttpServlet{
	String TOMCAT_HOME = System.getProperty("catalina.home");
	 PrintWriter pw ;
     public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
		pw= response.getWriter();
    }
	
	Utilities(PrintWriter pw)
	{
		this.pw = pw;
	}
	public String htmlToString(String file){
		
		StringBuilder contentBuilder = new StringBuilder();
		try {
			BufferedReader in = new BufferedReader(new FileReader(file));
			String str;
			while ((str = in.readLine()) != null) {
				
			contentBuilder.append(str);
		}
		in.close();
		} catch (IOException e) {
		}
		String content = contentBuilder.toString();
		
		return content;
	}
	public void printHtml(String file){
		String output = htmlToString(file);
		
		pw.print(output);
	}
	
	public void generateAddVehicleHtml(){
	pw.print("<section class='hero-area'>	<div class='container'><div class='row'>");
	pw.print("<div class='col-md-12'><div class='block'><form method = 'post' action ='AddVehicleDetails' >");
	pw.print("<table><tr><td> Id</td><td><input type ='text' name='id' style='color: black;' required></td></tr>");
	pw.print("<tr><td> Name</td><td><input type ='text' name='name' style='color: black;' required></td></tr>");
	pw.print("<tr><td> Price</td><td><input type ='text' name='price' style='color: black;' required></td></tr>");
	pw.print("<tr><td>Registration number</td><td><input type ='text' name='registrationnumber' style='color: black;' required></td></tr>");
	pw.print("<tr><td>Mileage</td><td><input type ='text' name='mileage' style='color: black;' required></td></tr>");
	pw.print("<tr><td> Type</td><td><select name='type' style='color: black;'><option value='standard'>standard</option>");
	pw.print("<option value='luxury'>luxury</option>");
	pw.print("<option value='suv'>suv</option>");
	pw.print("<option value='economy'>economy</option></select></td></tr>");
	pw.print("<tr><td>Passenger Capacity</td><td><input type ='text' name='passengercapacity' style='color: black;' required></td></tr>");
	pw.print("<tr><td>Transmission</td><td><input type ='text' name='transmission' style='color: black;' required></td></tr>");
	pw.print("<tr><td>Image</td><td><input type ='text' name='image' style='color: black;' required></td></tr>");
	pw.print("<tr><td>Locationid</td><td><input type ='text' name='locationid' style='color: black;' required></td></tr>");
	pw.print("<tr><td style='padding: 10% 20% 0; color:black;'><input type='submit' value='submit'></input></td></tr>");
	pw.print("</table></form></div></div></div></div>");
	pw.print("</section>");	
	}
	
	public void generateUpdateVehicleHtml(){
	pw.print("<section class='hero-area'>	<div class='container'><div class='row'>");
	pw.print("<div class='col-md-12'><div class='block'><form method = 'post' action ='UpdateVehicleDetails' >");
	pw.print("<table><tr><td> Id</td><td><input type ='text' name='id' style='color: black;' required></td></tr>");
	pw.print("<tr><td> Name</td><td><input type ='text' name='name' style='color: black;' required></td></tr>");
	pw.print("<tr><td> Price</td><td><input type ='text' name='price' style='color: black;' required></td></tr>");
	pw.print("<tr><td>Registration number</td><td><input type ='text' name='registrationnumber' style='color: black;' required></td></tr>");
	pw.print("<tr><td>Mileage</td><td><input type ='text' name='mileage' style='color: black;' required></td></tr>");
	pw.print("<tr><td> Type</td><td><select name='type' style='color: black;'><option value='standard'>standard</option>");
	pw.print("<option value='luxury'>luxury</option>");
	pw.print("<option value='suv'>suv</option>");
	pw.print("<option value='economy'>economy</option></select></td></tr>");
	pw.print("<tr><td>Passenger Capacity</td><td><input type ='text' name='passengercapacity' style='color: black;' required></td></tr>");
	pw.print("<tr><td>Transmission</td><td><input type ='text' name='transmission' style='color: black;' required></td></tr>");
	pw.print("<tr><td>Image</td><td><input type ='text' name='image' style='color: black;' required></td></tr>");
	pw.print("<tr><td>Locationid</td><td><input type ='text' name='locationid' style='color: black;' required></td></tr>");
	pw.print("<tr><td style='padding: 10% 20% 0; color:black;'><input type='submit' value='submit'></input></td></tr>");
	pw.print("</table></form></div></div></div></div>");
	pw.print("</section>");	
	}
	
	public void generateDeleteVehicleHtml(){
	pw.print("<section class='hero-area'>	<div class='container'><div class='row'>");
	pw.print("<div class='col-md-12'><div class='block'><form method = 'post' action ='DeleteVehicleDetails' >");
	pw.print("<table><tr><td>Vehicle Id</td><td><input type ='text' name='id' style='color: black;' required></td></tr>");
	pw.print("<tr><td style='padding: 10% 20% 0; color:black;'><input type='submit' value='submit'></input></td></tr>");
	pw.print("</table></form></div></div></div></div>");
	pw.print("</section>");	
	}
	
	


}
