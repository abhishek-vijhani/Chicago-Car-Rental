import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class Home extends HttpServlet{

     public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
		  HttpSession session = request.getSession();
		  String sname  = (String)session.getAttribute("uname");
		  String stype  = (String)session.getAttribute("utype");
		  PrintWriter pw = response.getWriter();
		 Utilities util = new Utilities(pw);
		 DealMatch dm = new DealMatch(pw);
		String page = request.getParameter("page");
		if(page==null){
			if(sname==null)
			{
			util.printHtml(getServletContext().getRealPath("index.html"));
			dm.generateDealContent();
			util.printHtml(getServletContext().getRealPath("footer.html"));
			}
			else{
				util.printHtml(getServletContext().getRealPath("indexsuccess.html"));
				dm.generateDealContent();
				util.printHtml(getServletContext().getRealPath("footer.html"));
			}

		}
		else if(page.equals("login")){
			util.printHtml(getServletContext().getRealPath("header.html"));
			util.printHtml(getServletContext().getRealPath("login.html"));
			util.printHtml(getServletContext().getRealPath("footer.html"));
		}

		else if(page.equals("logout")){
			util.printHtml(getServletContext().getRealPath("index.html"));
			dm.generateDealContent();
			util.printHtml(getServletContext().getRealPath("footer.html"));

		}
		
		else if(page.equals("loginerror")){
			util.printHtml(getServletContext().getRealPath("header.html"));
			util.printHtml(getServletContext().getRealPath("loginerror.html"));
			util.printHtml(getServletContext().getRealPath("footer.html"));
		}
		
		else if(page.equals("loginsuccess")){
			
			if(stype.equals("manager")){
				util.printHtml(getServletContext().getRealPath("indexsuccessmanager.html"));
			}
			else{
			util.printHtml(getServletContext().getRealPath("indexsuccess.html"));
			dm.generateDealContent();
			util.printHtml(getServletContext().getRealPath("footer.html"));
			}
		}
		
		else if(page.equals("register")){
			util.printHtml(getServletContext().getRealPath("header.html"));
			util.printHtml(getServletContext().getRealPath("register.html"));
			util.printHtml(getServletContext().getRealPath("footer.html"));
		}
		
		else if(page.equals("aboutus")){
			util.printHtml(getServletContext().getRealPath("aboutus.html"));
		}
    }
	
	

   


}
