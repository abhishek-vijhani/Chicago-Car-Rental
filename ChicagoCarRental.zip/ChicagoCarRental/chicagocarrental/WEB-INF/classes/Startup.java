import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class Startup extends HttpServlet{


    public void init()throws ServletException{
		 
          SAXParserDataStore sax = new SAXParserDataStore(getServletContext().getRealPath("VehicleCatalog.xml"));
	Map<Integer,Vehicle> vehicle = new HashMap<Integer,Vehicle>();
	vehicle = SAXParserDataStore.vehicles;
	MySQLDataStore.loadVehicles(vehicle);
	
    }


   


}
